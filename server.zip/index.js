const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "./.env") });

const express = require("express");
const cors = require("cors");
const nodemailer = require("nodemailer");

const { Bio, projects } = require("./data/constants");

const app = express();

// Proper CORS setup 👇
app.use(cors({
  origin: "*",
  methods: "GET,POST",
  allowedHeaders: "Content-Type, Authorization"
}));

app.use(express.json());

// Debug logs (optional)
app.use((req, res, next) => {
  console.log("Incoming Request:", req.method, req.url);
  next();
});

// Test endpoint
app.get("/ping", (req, res) => {
  res.send("pong");
});

// Bio API
app.get("/api/bio", (req, res) => {
  res.json(Bio);
});

// Projects API
app.get("/api/projects", (req, res) => {
  res.json(projects);
});

// Send Mail API
app.post("/api/send-email", async (req, res) => {
  try {
    const { name, email, subject, message } = req.body || {};

    if (!email || !message) {
      return res.status(400).json({ ok: false, error: "Email and message are required" });
    }

    const mailUser = process.env.MAIL;
    const mailPass = process.env.PASS;

    if (!mailUser || !mailPass) {
      return res.status(500).json({ ok: false, error: "Email server not configured" });
    }

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: mailUser,
        pass: mailPass
      },
    });

    await transporter.verify();

    await transporter.sendMail({
      from: mailUser,
      to: process.env.MAIL_TO,
      subject: subject || `Message from ${name}`,
      html: `
        <h3>New Contact Message</h3>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Message:</strong></p>
        <p>${message}</p>
      `,
    });

    res.json({ ok: true });

  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🔥 Server running on port ${PORT}`));
